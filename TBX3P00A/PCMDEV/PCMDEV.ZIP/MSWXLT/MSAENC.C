/************************************************************************/
/************************************************************************/
#include "windows.h"

#include "..\genpcm.h"                  /* PCM/APCM conversion defs     */
#include "..\pcmsup.h"                  /* PCM/APCM xlate lib defs      */

