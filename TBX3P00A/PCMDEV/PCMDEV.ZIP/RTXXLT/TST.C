main ()
{
    return (0);
}
